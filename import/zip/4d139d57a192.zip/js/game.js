/*========================================================================
      @作者：hugohua
      @说明：Game
      @最后编辑：$Author:: hugohua           $
                 $Date:: 2014-07-11 15:07#$
========================================================================*/

Pui.add('game',function(exports,P,$){
    'use strict';

    var $mask = $('#J_mask'),
        $navs = $('#J_navs');

    /**
     * 获取Flash
     * @param movieName
     * @returns {*}
     */
    var thisMovie = function(movieName) {
        if (window.document[movieName]) {
            return window.document[movieName];
        }
        if (document.getElementById(movieName)) {
            return document.getElementById(movieName);
        }
    };

    /**
     * 设置浮层位置居中
     * @param $pop
     * @returns {{top: number, left: number}}
     */
    var posCenter = function($pop){
        return {
            top:P.$win.height()/2 - $pop.height()/2,
            left:P.$win.width()/2 - $pop.width()/2
        }
    };

    var scroll = function(){
        $navs.scrollnav({
            cssNavItem:'a.J_nav'
//            pagerSensitive:0
        });

        $('.J_next').on('click',function(){
            $navs.scrollnav('goNext');
            return false;
        });

//        $navs.on('scrollnavdone',function(e,data){
//            console.log(data.index);
//        })
    };

    var share = function(){
        var $shareCnt = $('#J_navShareCnt'),
            $shareBtn = $('#J_navShare');
        $shareBtn.on('click',function(){
            $shareCnt.toggle();
            $(this).toggleClass('selected');
        });
        //懒加载
        $shareBtn.one('click',function(){
            shareCnt($('#J_copyUrl'));
        });

        //
        $navs.children('a:not(#J_navShare)').on('click.game',function(){
            $shareCnt.hide();
            $shareBtn.removeClass('selected');
        });

        //我的礼物分享按钮
        $('#J_giftShare').on('click.game',function(){
            exports.showSharePop();
        });
    };



    var shareCnt = function($id){
        //copy
        var clip = new ZeroClipboard($id),
            $shareSucc = $id.siblings('.J_shareSucc');
        clip.on("ready", function() {
            this.on("aftercopy", function(event) {
                $shareSucc.fadeIn();
                setTimeout(function(){
                    $shareSucc.fadeOut()
                },1000)
            });
        });

        clip.on("error", function(event) {
            ZeroClipboard.destroy();
            //加载失败后 则使用系统自带的copy
            if(P.detector.browser === 'ie'){
                window.clipboardData.setData('text', $('#J_url').val());
            }else{
                alert('您的浏览器不支持剪贴板操作，请自行复制。')
            }
        });
        //TODO 分享

    };


    /**
     * 显示浮层
     * @param $pop
     * @param score
     * @param rank
     */
    var showPop = function($pop,score,rank){
        score = score || 0;
        rank = rank || 0;
        $mask.show();
        $pop.show().css(posCenter($pop))
            .find('.J_score').text(score).end()
            .find('.J_rank').text(rank).end()
            //再玩一次
            .find('.J_playAgain').one('click',function(){
                $mask.add($pop).hide();
                $navs.scrollnav('goTo',1);
                try{
                    thisMovie("J_game").playAgain();
                }catch(e) {

                }
            }).end()
            //去分享
            .find('.J_goShare').off('click').on('click',function(){
                $pop.toggleClass('show_share')
            }).one('click',function(){
                //触发copy
                var id = $(this).attr('data-copy')
                shareCnt($(id))
            }).end()
            //去领礼物
            .find('.J_goGift').one('click',function(){
                var $gift = $('#J_popGift');
                showPop($gift);
                $pop.hide();
            }).end()
            //关闭
            .find('.J_close').one('click',function(){
                $mask.add($pop).hide();
            });

        //ESC 关闭
        P.$doc.off('keydown.game').on('keydown.game',function(e) {
            // ESCAPE key pressed
            if (e.keyCode == 27) {
                $mask.add($pop).hide();
                P.$doc.off('keydown.game')
            }
        });
    };

    /**
     * 显示好友排行榜
     */
//    var showFriendRank = function(){
//        var $rankCnt = $('#J_rankFriend');
//        $('#J_navRank').on('click.friend',function(){
//            showPop($rankCnt);
//        })
//    };


    /**
     * 全局按钮点击使用
     */
    var actBtn = function(){
        $('.J_btns a').on('click.game',function(){
            exports.toggleUse($(this));
            return false;
        })
    };

    /**
     * 切换显示隐藏是否使用
     */
    exports.toggleUse = function($a){
        $a.hide().siblings('a').show();
    };

    /**
     * 显示成功游戏浮层
     */
    exports.showSuccessPop = function(score,rank){
        var $rank = $('#J_rankSucc');
        showPop($rank,score,rank);
    };

    /**
     * 显示失败浮层
     * @param score
     * @param rank
     */
    exports.showFailPop = function(score,rank){
        var $rank = $('#J_rankFail');
        showPop($rank,score,rank);
    };

    /**
     * 显示好友排行榜浮层
     */
    exports.showFriendRank = function(){
        var $rankCnt = $('#J_rankFriend');
        showPop($rankCnt);
    };

    /**
     * 显示分享浮层
     */
    exports.showSharePop = function(){
        var $rankCnt = $('#J_giftPop');
        showPop($rankCnt);
    };

    /**
     * 游戏结束
     * @param score 游戏成绩
     */
    exports.gameComplete = function(score){
        score = score || 0;
        if(score >= 600){
            exports.showSuccessPop(score,333)
        }else{
            exports.showFailPop(score,444);
        }
    };


    exports.init = function(){
        exports.showSuccessPop(600,300);
        scroll();
    };

    exports.lazyInit = function(){
        share();
//        showFriendRank();
        actBtn();
    }

});